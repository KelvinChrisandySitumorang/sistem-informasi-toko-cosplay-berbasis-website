<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/compare', function () {
    return view('compare');
});
Route::get('/about-us', function () {
    return view('about-us');
});
Route::get('/contact-us', function () {
    return view('contact-us');
});
Auth::routes([
    'register' => false,
    'reset' => false,
    'verify' => false
]);

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::resource('/admin/criteria', App\Http\Controllers\AdminCriteria::class);
Route::resource('/admin/shop', App\Http\Controllers\AdminShop::class);
Route::resource('/admin/ahp-criteria-comparison', App\Http\Controllers\AdminAhpCriteriaComparison::class);
Route::resource('/admin/ahp-shop-comparison', App\Http\Controllers\AdminAhpShopComparison::class);
Route::resource('/admin/ahp-ir', App\Http\Controllers\AdminAhpIr::class);
Route::resource('/admin/smart-criteria', App\Http\Controllers\AdminSmartCriteria::class);
Route::resource('/admin/smart-shop', App\Http\Controllers\AdminSmartShop::class);
Route::resource('/admin/smart-rel-shop', App\Http\Controllers\AdminSmartRelShop::class);
Route::get('/admin/result', function () {
    return view('admin.result');
});
Route::get('/admin/result/ahp', function () {
    return view('admin.result.ahp');
});
Route::get('/admin/result/smart', function () {
    return view('admin.result.smart');
});
