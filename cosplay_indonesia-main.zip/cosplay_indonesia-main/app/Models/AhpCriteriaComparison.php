<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AhpCriteriaComparison extends Model
{
    use HasFactory;
    protected $fillable = [
        'criteria1_id',
        'criteria2_id',
        'value',
    ];
}
