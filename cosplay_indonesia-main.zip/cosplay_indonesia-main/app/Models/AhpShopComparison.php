<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AhpShopComparison extends Model
{
    use HasFactory;
    protected $fillable = [
        'shop1_id',
        'shop2_id',
        'criteria_id',
        'value',
        ];
}
