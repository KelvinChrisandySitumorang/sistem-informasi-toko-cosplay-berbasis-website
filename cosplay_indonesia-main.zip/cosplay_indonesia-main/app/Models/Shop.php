<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shop extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'image',
        'description',
        'phone',
        'city',
        'province',
      ];
    public function smartValue()
    {
        return $this->hasOne(SmartShop::class);
    }
}
