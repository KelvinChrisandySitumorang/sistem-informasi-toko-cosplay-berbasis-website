<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmartCriteria extends Model
{
    use HasFactory;
    protected $table = 'smart_criteria';
    protected $fillable = [
        'criteria_id',
        'weight',
    ];
}
