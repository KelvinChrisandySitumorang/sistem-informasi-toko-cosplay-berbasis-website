<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\AhpIr;

class AdminAhpIr extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $list = AhpIr::all();
        return view('admin.ahp_ir.index')
            ->with('list', $list);
    }
    public function create()
    {
        return view('admin.ahp_ir.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'total_criteria' => 'required',
            'value' => 'required|numeric|min:0|max:10',
        ]);
        
        AhpIr::create($request->except('_token'));

        return redirect('/admin/ahp-ir')
            ->with('success', 'Data created successfully.');
    }
    public function edit($id)
    {
        $data = AhpIr::find($id);
        return view('admin.ahp_ir.edit')
            ->with('data', $data);
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'total_criteria' => 'required',
            'value' => 'required|numeric|min:0|max:10',
        ]);
        
        $data = AhpIr::find($id);
        
        $data->total_criteria = $request->input('total_criteria');
        $data->value = $request->input('value');
        $data->save();
        return redirect('/admin/ahp-ir')
            ->with('success', 'Data updated successfully.');
    }
    public function destroy($id)
    {
        AhpIr::where('id', $id)->delete();
        return redirect('/admin/ahp-ir')
            ->with('success', 'Data deleted successfully.');
    }
}
