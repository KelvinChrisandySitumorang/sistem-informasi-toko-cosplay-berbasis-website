<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Criteria;
use App\Models\AhpCriteriaComparison;

class AdminAhpCriteriaComparison extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $list = AhpCriteriaComparison::get();
        $listCriteria = Criteria::with('smartValue')->get();
        return view('admin.ahp_criteria_comparison.index')
            ->with('list', $list)
            ->with('listCriteria', $listCriteria);
    }
    public function create()
    {

    }
    public function store(Request $request)
    {
        $request->validate([
            'data.*.value' => 'required|numeric|min:0|max:10',
        ]);
        foreach($request->data as $value) {
            $data = AhpCriteriaComparison::firstOrNew(['criteria1_id'=> $value['criteria1_id'], 'criteria2_id'=> $value['criteria2_id']]);
            $data->value = $value['value'];
            $data->save();
        }
        return redirect('/admin/ahp-criteria-comparison')
            ->with('success', 'Data updated successfully.');

    }
    public function edit($id)
    {

    }
    public function update(Request $request, $id)
    {   

    }
    public function destroy($id)
    {
        
    }
}
