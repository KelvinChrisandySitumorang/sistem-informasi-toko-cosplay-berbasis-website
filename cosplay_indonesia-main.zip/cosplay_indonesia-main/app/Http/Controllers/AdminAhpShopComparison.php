<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shop;
use App\Models\Criteria;
use App\Models\AhpShopComparison;

class AdminAhpShopComparison extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $listShop = Shop::with('smartValue')->get();
        $list = AhpShopComparison::get();
        $listCriteria = Criteria::with('smartValue')->get();
        return view('admin.ahp_shop_comparison.index')
            ->with('list', $list)
            ->with('listShop', $listShop)
            ->with('listCriteria', $listCriteria);
    }
    public function create()
    {

    }
    public function store(Request $request)
    {
        $request->validate([
            'data.*.value' => 'required|numeric|min:0|max:10',
        ]);
        foreach($request->data as $value) {
            $data = AhpShopComparison::firstOrNew(['shop1_id'=> $value['shop1_id'], 'shop2_id'=> $value['shop2_id'], 'criteria_id'=> $value['criteria_id']]);
            $data->value = $value['value'];
            $data->save();
        }
        return redirect('/admin/ahp-shop-comparison')
            ->with('success', 'Data updated successfully.');

    }
    public function edit($id)
    {

    }
    public function update(Request $request, $id)
    {   

    }
    public function destroy($id)
    {
        
    }
}
