<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Shop;

class AdminShop extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $list = Shop::all();
        return view('admin.shop.index')
            ->with('list', $list);
    }
    public function create()
    {
        return view('admin.shop.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'phone' => 'required|numeric',
            'city' => 'required',
            'province' => 'required',
        ]);
        $fileNamePrefix = time().'.';
        if ($request->hasFile('image_file')) {
            $name = $fileNamePrefix.$request->file('image_file')->extension();
            $request->file('image_file')->move(public_path('uploads'), $name);
            $request['image'] = 'uploads/'.$name;
        }
        Shop::create($request->except('_token', 'image_file'));

        return redirect('/admin/shop')
            ->with('success', 'Data created successfully.');
    }
    public function edit($id)
    {
        $data = Shop::find($id);
        return view('admin.shop.edit')
            ->with('data', $data);
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'phone' => 'required|numeric',
            'city' => 'required',
            'province' => 'required',
        ]);
        
        $data = Shop::find($id);
        $fileNamePrefix = time().'.';
        if ($request->hasFile('image_file')) {
            $name = $fileNamePrefix.$request->file('image_file')->extension();
            $request->file('image_file')->move(public_path('uploads'), $name);
            $data->image = 'uploads/'.$name;
        }
        $data->name = $request->input('name');
        $data->description = $request->input('description');
        $data->phone = $request->input('phone');
        $data->city = $request->input('city');
        $data->province = $request->input('province');
        $data->save();
        return redirect('/admin/shop')
            ->with('success', 'Data updated successfully.');
    }
    public function destroy($id)
    {
        Shop::where('id', $id)->delete();
        return redirect('/admin/shop')
            ->with('success', 'Data deleted successfully.');
    }
}
