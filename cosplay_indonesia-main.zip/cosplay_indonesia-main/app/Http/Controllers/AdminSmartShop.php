<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Shop;
use App\Models\SmartShop;

class AdminSmartShop extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $list = Shop::with('smartValue')->get();
        return view('admin.smart_shop.index')
            ->with('list', $list);
    }
    public function create()
    {

    }
    public function store(Request $request)
    {

    }
    public function edit($id)
    {
        $data = SmartShop::where('shop_id', $id)->first();
        return view('admin.smart_shop.edit')
            ->with('data', $data)->with('id', $id);
    }
    public function update(Request $request, $id)
    {   
        
        $data = SmartShop::firstOrNew(['shop_id'=> $id]);
        $data->value = $request->value;
        $data->save();
        return redirect('/admin/smart-shop')
            ->with('success', 'Data updated successfully.');
    }
    public function destroy($id)
    {
        
    }
}
