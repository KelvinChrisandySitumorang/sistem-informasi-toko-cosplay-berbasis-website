<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Criteria;
use App\Models\SmartCriteria;

class AdminSmartCriteria extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $list = Criteria::with('smartValue')->get();
        return view('admin.smart_criteria.index')
            ->with('list', $list);
    }
    public function create()
    {

    }
    public function store(Request $request)
    {

    }
    public function edit($id)
    {
        $data = SmartCriteria::where('criteria_id', $id)->first();
        return view('admin.smart_criteria.edit')
            ->with('data', $data)->with('id', $id);
    }
    public function update(Request $request, $id)
    {   
        $request->validate([
            'weight' => 'required|numeric|min:1|max:10',
        ]);
        $data = SmartCriteria::firstOrNew(['criteria_id'=> $id]);
        $data->weight = $request->weight;
        $data->save();
        return redirect('/admin/smart-criteria')
            ->with('success', 'Data updated successfully.');
    }
    public function destroy($id)
    {
        
    }
}
