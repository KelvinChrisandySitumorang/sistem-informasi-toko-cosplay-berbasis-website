<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Shop;
use App\Models\Criteria;
use App\Models\SmartRelShop;

class AdminSmartRelShop extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $listShop = Shop::with('smartValue')->get();
        $listCriteria = Criteria::with('smartValue')->get();
        $list = SmartRelShop::get();
        return view('admin.smart_rel_shop.index')
            ->with('list', $list)
            ->with('listShop', $listShop)
            ->with('listCriteria', $listCriteria);
    }
    public function create()
    {

    }
    public function store(Request $request)
    {

    }
    public function edit($id)
    {
        $listShop = Shop::with('smartValue')->get();
        $listCriteria = Criteria::with('smartValue')->get();
        $list = SmartRelShop::where('shop_id', $id)->get();
        return view('admin.smart_rel_shop.edit')
            ->with('shop_id', $id)
            ->with('list', $list)
            ->with('listShop', $listShop)
            ->with('listCriteria', $listCriteria);
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'data.*.value' => 'required|numeric|min:1|max:10',
        ]);
        foreach($request->data as $value) {
            $data = SmartRelShop::firstOrNew(['shop_id'=> $id, 'criteria_id'=> $value['criteria_id']]);
            $data->value = $value['value'];
            $data->save();
        }
        return redirect('/admin/smart-rel-shop')
            ->with('success', 'Data updated successfully.');
    }
    public function destroy($id)
    {
        
    }
}
