<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Criteria;

class AdminCriteria extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $list = Criteria::all();
        return view('admin.criteria.index')
            ->with('list', $list);
    }
    public function create()
    {
        return view('admin.criteria.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);
        
        Criteria::create($request->except('_token'));

        return redirect('/admin/criteria')
            ->with('success', 'Data created successfully.');
    }
    public function edit($id)
    {
        $data = Criteria::find($id);
        return view('admin.criteria.edit')
            ->with('data', $data);
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
        ]);
        
        $data = Criteria::find($id);
        
        $data->name = $request->input('name');
        $data->save();
        return redirect('/admin/criteria')
            ->with('success', 'Data updated successfully.');
    }
    public function destroy($id)
    {
        Criteria::where('id', $id)->delete();
        return redirect('/admin/criteria')
            ->with('success', 'Data deleted successfully.');
    }
}
