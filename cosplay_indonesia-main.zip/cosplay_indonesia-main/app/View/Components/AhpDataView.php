<?php

namespace App\View\Components;

use Illuminate\View\Component;
use App\Models\Shop;
use App\Models\Criteria;
use App\Models\AhpCriteriaComparison;
use App\Models\AhpShopComparison;

class AhpDataView extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        $shop_list = Shop::all();
        $criteria_list = Criteria::with('smartValue')->get();
        $ahp_criteria_comparison_list = AhpCriteriaComparison::all();
        $ahp_shop_comparison_list = AhpShopComparison::all();
        return view('components.ahp-data-view', compact(
            'shop_list',
            'criteria_list',
            'ahp_criteria_comparison_list',
            'ahp_shop_comparison_list',
        ));
    }
}
