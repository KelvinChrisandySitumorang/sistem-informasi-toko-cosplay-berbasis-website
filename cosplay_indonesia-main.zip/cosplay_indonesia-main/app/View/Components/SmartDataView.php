<?php

namespace App\View\Components;

use Illuminate\View\Component;
use App\Models\Shop;
use App\Models\Criteria;
use App\Models\SmartRelShop;

class SmartDataView extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        $shop_list = Shop::all();
        $criteria_list = Criteria::with('smartValue')->get();
        $rel_shop_list = SmartRelShop::all();
        return view('components.smart-data-view', compact(
            'shop_list',
            'criteria_list',
            'rel_shop_list',
        ));
    }
}
