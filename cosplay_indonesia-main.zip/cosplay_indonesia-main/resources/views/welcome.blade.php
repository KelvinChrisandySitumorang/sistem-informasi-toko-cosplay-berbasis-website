@extends('layouts.plain')

@section('content')
<div class="banner header-text">
    <div class="owl-banner owl-carousel">
    <div class="banner-item-01">
    </div>
    <div class="banner-item-02">
    </div>
    <div class="banner-item-03">
        </div>
    </div>
</div>

<div class="latest-products">
  <div class="container">
    <x-shop-list/>
  </div>
</div>
@endsection
