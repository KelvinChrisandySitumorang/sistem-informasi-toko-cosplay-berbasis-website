@extends('layouts.plain')

@section('content')
 <!-- Page Content -->
 <div class="page-heading contact-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h2>HUBUNGI CUSTOMER CARE KAMI</h2>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="find-us">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Our Location on Maps</h2>
            </div>
          </div>
          <div class="col-md-8">
<!-- How to change your own map point
	1. Go to Google Maps
	2. Click on your location point
	3. Click "Share" and choose "Embed map" tab
	4. Copy only URL and paste it within the src="" field below
-->
            <div id="map">
              <iframe src="https://maps.google.com/maps?q=universitas%20indonesia&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="330px" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-md-4">
            <div class="left-content">
              <h4>Customer Care</h4>
              <p class="text-left">Phone&nbsp; &nbsp; &nbsp;: 08123 8595 24 / 0812 3357 7331&nbsp; Email&nbsp; &nbsp; &nbsp; : cs@cosplayindonesia.com&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Kami akan menghubungi Anda dalam waktu 24-48 jam&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;</p>
            </div>
          </div>
        </div>
      </div>
    </div>

@endsection
