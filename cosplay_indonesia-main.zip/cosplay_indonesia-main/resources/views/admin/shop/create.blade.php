@extends('layouts.app')

@section('content')
<div class="container">
    @if($errors->any())
        <div class="alert alert-danger">
            <p><strong>Opps Something went wrong</strong></p>
            <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
            </ul>
        </div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">{{session('success')}}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{session('error')}}</div>
    @endif

    <form action="/admin/shop" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="name" class="form-label">Nama</label>
            <input class="form-control" type="text" name="name">
        </div>
        <div class="form-group">
            <label for="image" class="form-label">Gambar</label>
            <input class="form-control" type="file" name="image_file">
        </div>
        <div class="form-group">
            <label for="description" class="form-label">Deskripsi</label>
            <input class="form-control" type="text" name="description">
        </div>
        <div class="form-group">
            <label for="phone" class="form-label">Telpon</label>
            <input class="form-control" type="text" name="phone">
        </div>
        <div class="form-group">
            <label for="city" class="form-label">Kota</label>
            <input class="form-control" type="text" name="city">
        </div>
        <div class="form-group">
            <label for="province" class="form-label">Province</label>
            <input class="form-control" type="text" name="province">
        </div>
        <div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ URL::to('admin/shop') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection
