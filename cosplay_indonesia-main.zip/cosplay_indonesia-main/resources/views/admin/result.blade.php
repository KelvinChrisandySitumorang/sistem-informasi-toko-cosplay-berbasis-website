
@extends('layouts.app')

@section('content')
<div class="container">
    <x-ahp-data></x-ahp-data>
</div>
<div class="container">
    <x-smart-data/>
</div>

@endsection
