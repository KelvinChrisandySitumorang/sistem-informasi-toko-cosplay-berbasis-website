@extends('layouts.app')

@section('content')
<div class="container">
    @if($errors->any())
        <div class="alert alert-danger">
            <p><strong>Opps Something went wrong</strong></p>
            <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
            </ul>
        </div>
    @endif
    @if(session('success'))
        <div class="alert alert-success">{{session('success')}}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{session('error')}}</div>
    @endif
    <form action="/admin/ahp-criteria-comparison" method="POST" enctype="multipart/form-data">
        @csrf
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <td>Kriteria 1</td>
                    <td>Kriteria 2</td>
                    <td>Value</td>
                </tr>
            </thead>
            <tbody>
                @php
                    $index = 0;
                @endphp
                @foreach($listCriteria as $i => $criteria1)
                    @foreach($listCriteria as $j => $criteria2)
                        @if ($j > $i)
                            @php
                                $relValue = $list->filter(function($value, $key) use($criteria1, $criteria2) {
                                        return $value->criteria1_id == $criteria1->id && $value->criteria2_id == $criteria2->id;
                                })->first();
                            @endphp
                                <tr>
                                    <td>
                                        {{ $criteria1->name }}
                                        @if (!isset($relValue))
                                            <span class="position-absolute top-0 start-100 translate-middle badge bg-primary" >Baru</span>
                                        @endif
                                    </td>
                                    <td>
                                        {{ $criteria2->name }}
                                        @if (!isset($relValue))
                                            <span class="position-absolute top-0 start-100 translate-middle badge bg-primary" >Baru</span>
                                        @endif
                                    </td>
                                    <td>
                                    <input class="invisible" type="text" name="data[{{$index}}][criteria1_id]" value="{{ $criteria1->id }}">
                                    <input class="invisible" type="text" name="data[{{$index}}][criteria2_id]" value="{{ $criteria2->id }}">
                                        <input class="form-control" type="text" name="data[{{$index}}][value]" value="{{isset($relValue) ? $relValue->value : 1 }}">
                                    </td>
                                </tr>
                            @php
                                $index = $index + 1;
                            @endphp
                        @endif
                    @endforeach
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3"><button type="submit" class="btn btn-primary">Simpan</button></td>
                </tr>
            </tfoot>
        </table>
    </form>
</div>
@endsection
