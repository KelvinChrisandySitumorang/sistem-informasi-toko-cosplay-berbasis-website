@extends('layouts.app')

@section('content')
<div class="container">
    @if($errors->any())
        <div class="alert alert-danger">
            <p><strong>Opps Something went wrong</strong></p>
            <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
            </ul>
        </div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">{{session('success')}}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{session('error')}}</div>
    @endif
    <form action="/admin/ahp-shop-comparison" method="POST" enctype="multipart/form-data">
        @csrf
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <td>Kriteria</td>
                    <td>Toko 1</td>
                    <td>Toko 2</td>
                    <td>Value</td>
                </tr>
            </thead>
            <tbody>
                @php
                    $index = 0;
                @endphp
                @foreach($listCriteria as $h => $criteria)
                    @foreach($listShop as $i => $shop1)
                        @foreach($listShop as $j => $shop2)
                            @if ($j > $i)
                                @php
                                    $relValue = $list->filter(function($value, $key) use($shop1, $shop2, $criteria) {
                                            return $value->shop1_id == $shop1->id && $value->shop2_id == $shop2->id && $value->criteria_id == $criteria->id;
                                    })->first();
                                @endphp
                                    <tr>
                                        <td>
                                            {{ $criteria->name }}
                                            @if (!isset($relValue))
                                                <span class="position-absolute top-0 start-100 translate-middle badge bg-primary" >Baru</span>
                                            @endif
                                        </td>
                                        <td>
                                            {{ $shop1->name }}
                                            @if (!isset($relValue))
                                                <span class="position-absolute top-0 start-100 translate-middle badge bg-primary" >Baru</span>
                                            @endif
                                        </td>
                                        <td>
                                            {{ $shop2->name }}
                                            @if (!isset($relValue))
                                                <span class="position-absolute top-0 start-100 translate-middle badge bg-primary" >Baru</span>
                                            @endif
                                        </td>
                                        <td>
                                        <input class="invisible" type="text" name="data[{{$index}}][criteria_id]" value="{{ $criteria->id }}">
                                        <input class="invisible" type="text" name="data[{{$index}}][shop1_id]" value="{{ $shop1->id }}">
                                        <input class="invisible" type="text" name="data[{{$index}}][shop2_id]" value="{{ $shop2->id }}">
                                            <input class="form-control" type="text" name="data[{{$index}}][value]" value="{{isset($relValue) ? $relValue->value : 1 }}">
                                        </td>
                                    </tr>
                                @php
                                    $index = $index + 1;
                                @endphp
                            @endif
                        @endforeach
                    @endforeach
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3"><button type="submit" class="btn btn-primary">Simpan</button></td>
                </tr>
            </tfoot>
        </table>
    </form>
</div>
@endsection
