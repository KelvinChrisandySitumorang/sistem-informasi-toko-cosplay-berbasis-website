@extends('layouts.app')

@section('content')
<div class="container">
    @if($errors->any())
        <div class="alert alert-danger">
            <p><strong>Opps Something went wrong</strong></p>
            <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
            </ul>
        </div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">{{session('success')}}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{session('error')}}</div>
    @endif

    <form action="/admin/smart-rel-shop/{{$shop_id}}" method="POST" enctype="multipart/form-data">
        @method('PATCH')
        @csrf
        
        @foreach($listCriteria as $key => $criteria)
            @php
                $relValue = $list->filter(function($value, $key) use($criteria, $shop_id) {
                        return $value->criteria_id == $criteria->id && $value->shop_id == $shop_id;
                })->first();
            @endphp
            <input class="invisible" name="data[{{$key}}][criteria_id]" value="{{$criteria->id}}"/>
            <div class="form-group">
                <label for="data[{{$key}}]value" class="form-label">{{ $criteria->name }}</label>
                <input class="form-control" type="text" name="data[{{$key}}][value]" value="{{isset($relValue) ? $relValue->value : '' }}">
            </div>
        @endforeach
        <div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ URL::to('admin/smart-rel-shop') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection
