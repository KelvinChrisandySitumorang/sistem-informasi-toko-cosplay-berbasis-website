@extends('layouts.app')

@section('content')
<div class="container">
    @if(session('success'))
        <div class="alert alert-success">{{session('success')}}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{session('error')}}</div>
    @endif
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <td>ID</td>
                <td>Nama Toko</td>
                @foreach($listCriteria as $key => $value)
                    <td>{{ $value -> name }}</td>
                @endforeach
                <td></td>
            </tr>
        </thead>
        <tbody>
        @foreach($listShop as $key => $shop)
            <tr>
                <td>{{ $shop->id }}</td>
                <td>{{ $shop->name }}</td>
                
                @foreach($listCriteria as $keyCriteria => $criteria)
                    @php
                        $relValue = $list->filter(function($value, $key) use($criteria, $shop) {
                                return $value->criteria_id == $criteria->id && $value->shop_id == $shop->id;
                        })->first();
                    @endphp
                    <td>{{ isset($relValue) ? $relValue->value : "" }}</td>
                @endforeach
                <td>
                    <a class="btn btn-small btn-primary" href="{{ URL::to('admin/smart-rel-shop/' . $shop->id . '/edit') }}">Ubah</a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
