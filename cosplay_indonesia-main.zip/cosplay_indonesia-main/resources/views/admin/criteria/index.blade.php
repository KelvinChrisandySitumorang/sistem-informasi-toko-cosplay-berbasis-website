@extends('layouts.app')

@section('content')
<div class="container">
    @if(session('success'))
        <div class="alert alert-success">{{session('success')}}</div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">{{session('error')}}</div>
    @endif
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <td>ID</td>
                <td>Nama</td>
                <td><a href="{{ URL::to('admin/criteria/create') }}" class="btn btn-small btn-primary">Tambah</a></td>
            </tr>
        </thead>
        <tbody>
        @foreach($list as $key => $value)
            <tr>
                <td>{{ $value->id }}</td>
                <td>{{ $value->name }}</td>
                <td>
                    <a class="btn btn-small btn-primary" href="{{ URL::to('admin/criteria/' . $value->id . '/edit') }}">Ubah</a>
                    <form action="/admin/criteria/{{$value->id}}" method="POST">
                        @method('DELETE')
                        @csrf                  
                        <button type="submit" class="btn btn-small btn-danger">Hapus</a>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
