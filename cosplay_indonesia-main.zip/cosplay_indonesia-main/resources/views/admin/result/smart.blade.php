
@extends('layouts.app')

@section('content')
<div class="container">
    <x-smart-data/>
</div>

@endsection
