
@extends('layouts.app')

@section('content')
<div class="container">
    <x-ahp-data></x-ahp-data>
</div>

@endsection
