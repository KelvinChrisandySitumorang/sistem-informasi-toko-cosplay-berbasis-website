<div class="row">
    @foreach ($shop_list as $shop)
        <x-shop-card :shop="$shop"/>
    @endforeach
</div>
