<header class="">
    <nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="/"><h2>Cosplay <em>Indonesia</em></h2></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item {{ request()->is('/') ? 'active' : '' }}">
                <a class="nav-link" href="/">Home
                    <span class="sr-only">(current)</span>
                </a>
                </li> 
                <li class="nav-item {{ request()->is('compare') ? 'active' : '' }}">
                <a class="nav-link" href="/compare">Perbandingan</a>
                </li>
                <li class="nav-item {{ request()->is('about-us') ? 'active' : '' }}">
                <a class="nav-link" href="/about-us">Tentang Kami</a>
                </li>
                <li class="nav-item {{ request()->is('contact-us') ? 'active' : '' }}">
                <a class="nav-link" href="/contact-us">Hubungi Kami</a>
                </li>
            </ul>
        </div>
    </div>
    </nav>
</header>
