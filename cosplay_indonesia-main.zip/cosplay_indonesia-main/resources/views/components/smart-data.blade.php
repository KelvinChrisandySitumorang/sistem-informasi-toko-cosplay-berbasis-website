@php
    $criteria_total = 0;
    $criteria_normal_total = 0;
    $result_total = 0;
    $result = [];
$class_calculation = '';
@endphp
<style>
.hide {
    display: none;
}
</style>
<div class="row">
    <div class="col-md-12">
        <h3>METODE SMART</h3>
        <p>"Disini terisi list-list toko terbaik mengguanakan metode SMART yang telah di data oleh admin website berdasarkan perhitungan dan data yang diterima,silahkan memilih toko favorit Kalian"</p>
    </div>
    <div class="card col-md-12 {{ $class_calculation }}">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Normalisasi Kriteria</th>
                                @foreach ($criteria_list as $criteria)
                                    <th>{{ $criteria->name }}</th>
                                @endforeach
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>Bobot</th>
                                @foreach ($criteria_list as $criteria)
                                    @php
                                        $criteria_value = isset($criteria->smartValue) ? $criteria->smartValue->weight : 1;
                                        $criteria_total = $criteria_total + $criteria_value;
                                    @endphp
                                    <td>{{ $criteria_value }}</td>
                                @endforeach
                                <td>{{ $criteria_total }}</td>
                            </tr>
                            <tr>
                                <th>Bobot Normal</th>
                                @foreach ($criteria_list as $criteria)
                                    @php
                                        $criteria_value = isset($criteria->smartValue) ? $criteria->smartValue->weight : 1;
                                        $criteria_value = $criteria_total == 0 ? 0 : $criteria_value / $criteria_total;
                                        $criteria_normal_total = $criteria_normal_total + $criteria_value;
                                        $criteria->normalValue = $criteria_value;
                                    @endphp
                                    <td>{{ round($criteria_value, 4) }}</td>
                                @endforeach
                                <td>{{ $criteria_normal_total }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Data Alternatif</th>
                                @foreach ($criteria_list as $criteria)
                                    <th>{{ $criteria->name }}</th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($shop_list as $shop)
                                @php
                                    $result_total = 0;
                                @endphp
                                <tr>
                                    <th>{{$shop->name}}</th>
                                    @foreach($criteria_list as $keyCriteria => $criteria)
                                        @php
                                            $relValue = $rel_shop_list->filter(function($value, $key) use($criteria, $shop) {
                                                    return $value->criteria_id == $criteria->id && $value->shop_id == $shop->id;
                                            })->first();
                                            $result_value = isset($relValue) ? $relValue->value * $criteria->normalValue : 0;
                                            $result[$shop->id]['normal_value_list'][$criteria->id] = $result_value;
                                            $result_total = $result_total + $result_value;
                                            $result[$shop->id]['total'] = $result_total;
                                            $result[$shop->id]['name'] = $shop->name;
                                            $result[$shop->id]['data'] = $shop;
                                        @endphp
                                        <td>{{ isset($relValue) ? $relValue->value : "" }}</td>
                                    @endforeach
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <br>
            @php
                uasort($result, function($a, $b) {
                    if ($a['total'] == $b['total']) return 0;
                    return $b['total'] > $a['total'];
                })
            @endphp
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Ranking</th>
                        <th>Normalisasi Terbobot</th>
                        @foreach ($criteria_list as $criteria)
                            <th>{{ $criteria->name }}</th>
                        @endforeach
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                @php
                    $index = 1;
                @endphp
                    @foreach ($result as $key => $shop)
                        <tr>
                            <th>{{ $index }}</th>
                            <th>{{ $shop['name'] }}</th>
                            @foreach($criteria_list as $keyCriteria => $criteria)
                                <td>{{ round($shop['normal_value_list'][$criteria->id], 4) }}</td>
                            @endforeach
                            <td>{{ round($shop['total'], 4)}}</td>
                        </tr>
                        @php
                            $index = $index + 1;
                        @endphp
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-12 {{ $class_calculation }}">
    </div>
</div>
<div class="row">
    @foreach ($result as $shop)
        <x-shop-card :shop="$shop['data']"/>
    @endforeach
</div>
