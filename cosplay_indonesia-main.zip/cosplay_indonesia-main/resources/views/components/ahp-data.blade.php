@php
$pv_kriteria = [];
$pv_kriteria_column_total = [];
$result_list = [];
$class_calculation = '';
@endphp
<style>
.hide {
    display: none;
}
</style>
<div class="row">
    <div class="col-md-12">
        <h3>METODE AHP</h3>
        <p>"Disini terisi list-list toko terbaik menggunakan metode AHP yang telah di data oleh admin website berdasarkan data yang diterima,silahkan memilih toko favorit kalian."</p>
    </div>
    <div class="card col-md-12 {{ $class_calculation }}">
        <div class="card-body">
            <div class="row"><h4 class="col-md-12">Kriteria</h4></div>
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Matrix Perbandingan Berpasangan</th>
                                @foreach ($criteria_list as $criteria)
                                    @php
                                        $pv_kriteria_column_total[$criteria->id] = array('total' => 0, 'shop_list' => []);
                                    @endphp
                                    <th>{{ $criteria->name }}</th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($criteria_list as $criteria_row)
                                <tr>
                                    <th>{{ $criteria_row->name }}</th>
                                    @foreach ($criteria_list as $criteria_col)
                                        @php
                                            $value = 1;
                                            $search_data = $ahp_criteria_comparison_list
                                                ->where('criteria1_id', $criteria_row->id)
                                                ->where('criteria2_id', $criteria_col->id);
                                            if ($search_data->isNotEmpty()) {
                                                $value = $search_data->first()->value;
                                            }
                                            
                                            $search_data = $ahp_criteria_comparison_list
                                                ->where('criteria2_id', $criteria_row->id)
                                                ->where('criteria1_id', $criteria_col->id);
                                            if ($search_data->isNotEmpty()) {
                                                $value = 1 / $search_data->first()->value;
                                            }
                                            $pv_kriteria[$criteria_row->id][$criteria_col->id] = array(
                                                'value' => $value
                                            );
                                            $pv_kriteria_column_total[$criteria_col->id]['total'] = $pv_kriteria_column_total[$criteria_col->id]['total'] + $value;
                                            
                                        @endphp
                                        <td>{{ round($value, 4) }}</td>
                                    @endforeach
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Jumlah</th>
                                @foreach($pv_kriteria_column_total as $column)
                                    <td>{{ round($column['total'], 4) }}</td>
                                @endforeach
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Matrix Nilai</th>
                                @foreach ($criteria_list as $criteria)
                                    <th>{{ $criteria->name }}</th>
                                @endforeach
                                <th>Jumlah</th>
                                <th>Priority Vector</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($criteria_list as $criteria_row)
                                @php
                                    $pv_total = 0;
                                    $eigen_total = 0;
                                @endphp
                                <tr>
                                    <th>{{ $criteria_row->name }}</th>
                                    @foreach ($criteria_list as $criteria_col)
                                        @php
                                            $value = $pv_kriteria[$criteria_row->id][$criteria_col->id]['value'];
                                            $pv = $value / $pv_kriteria_column_total[$criteria_col->id]['total'];
                                            $pv_total = $pv_total + $pv;
                                            $eigen_total = $eigen_total + $pv_kriteria_column_total[$criteria_col->id]['total'] * ($pv_total / $criteria_list->count());
                                        @endphp
                                        <td>{{ round($pv, 4) }}</td>
                                    @endforeach
                                    @php
                                        $pv_criteria = $pv_total / $criteria_list->count();
                                        $pv_kriteria_column_total[$criteria_row->id]['pv'] = $pv_criteria;
                                    @endphp
                                    <td>{{ round($pv_total, 4)}}</td>
                                    <td>{{ round($pv_criteria, 4)}}</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="{{ $criteria_list->count() + 2 }}">Principe Eigen Vector (λ maks)</th>
                                <td>{{ round($eigen_total, 4)}}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

        </div>
    </div>
    <div class="card col-md-12 {{ $class_calculation }}">
        <div class="card-body">
            <div class="row"><h4>Toko</h4></div>
        </div>
    @foreach($criteria_list as $criteria)
        @php
            $pv_kriteria = [];
        @endphp
        <div class="row">
            <div class="col-md-12 {{ $class_calculation }}">
                <h5>{{ $criteria->name }}</h5>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12 {{ $class_calculation }}">
                <h5>Matrix Perbandingan Berpasangan</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Toko</th>
                            @foreach ($shop_list as $shop)
                                @php
                                    $pv_kriteria_column_total[$criteria->id]['shop_list'][$shop->id] = array('total' => 0, 'data' => $shop);
                                @endphp
                                <th>{{ $shop->name }}</th>
                            @endforeach
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($shop_list as $shop_row)
                            <tr>
                                <th>{{ $shop_row->name }}</th>
                                @foreach ($shop_list as $shop_col)
                                @php
                                    $value = 1;
                                    $search_data = $ahp_shop_comparison_list
                                        ->where('criteria_id', $criteria->id)
                                        ->where('shop1_id', $shop_row->id)
                                        ->where('shop2_id', $shop_col->id);
                                    if ($search_data->isNotEmpty()) {
                                        $value = $search_data->first()->value;
                                    }
                                    
                                    $search_data = $ahp_shop_comparison_list
                                        ->where('criteria_id', $criteria->id)
                                        ->where('shop2_id', $shop_row->id)
                                        ->where('shop1_id', $shop_col->id);
                                    if ($search_data->isNotEmpty()) {
                                        $value = 1 / $search_data->first()->value;
                                    }
                                    $pv_kriteria[$shop_row->id][$shop_col->id] = array(
                                        'value' => $value
                                    );
                                    $pv_kriteria_column_total[$criteria->id]['shop_list'][$shop_col->id]['total'] = $pv_kriteria_column_total[$criteria->id]['shop_list'][$shop_col->id]['total'] + $value;
                                    
                                @endphp
                                <td>{{ round($value, 4) }}</td>
                            @endforeach
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Jumlah</th>
                            @foreach($pv_kriteria_column_total[$criteria->id]['shop_list'] as $column)
                                <td>{{ round($column['total'], 4) }}</td>
                            @endforeach
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 {{ $class_calculation }}">
                <h5>Matrix Nilai</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Toko</th>
                            @foreach ($shop_list as $shop)
                                <th>{{ $shop->name }}</th>
                            @endforeach
                            <th>Jumlah</th>
                            <th>Priority Vector</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach ($shop_list as $shop_row)
                        @php
                            $pv_total = 0;
                            $eigen_total = 0;
                        @endphp
                        <tr>
                            <th>{{ $shop_row->name }}</th>
                            @foreach ($shop_list as $shop_col)
                                @php
                                    $value = $pv_kriteria[$shop_row->id][$shop_col->id]['value'];
                                    $pv = $value / $pv_kriteria_column_total[$criteria->id]['shop_list'][$shop_col->id]['total'];
                                    $pv_total = $pv_total + $pv;
                                    $eigen_total = $eigen_total + $pv_kriteria_column_total[$criteria->id]['shop_list'][$shop_col->id]['total'] * ($pv_total / $shop_list->count());
                                @endphp
                                <td>{{ round($pv, 4) }}</td>
                            @endforeach
                            @php
                                $pv_shop = $pv_total / $shop_list->count();
                                $pv_kriteria_column_total[$criteria->id]['shop_list'][$shop_row->id]['pv'] = $pv_shop;
                            @endphp
                            <td>{{ round($pv_total, 4)}}</td>
                            <td>{{ round($pv_shop, 4)}}</td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="{{ $shop_list->count() + 2 }}">Principe Eigen Vector (λ maks)</th>
                        <td>{{ round($eigen_total, 4)}}</td>
                    </tr>
                </tfoot>
                </table>
            </div>
        </div>
    @endforeach
    <div class="row">
        <div class="col-md-12 {{ $class_calculation }}">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Overall Composite Height</th>
                        <th>Priority Vector (rata-rata)</th>
                        @foreach ($shop_list as $shop)
                            @php
                                $result_list[$shop->id] = array('pv' => 0, 'data' => $shop);
                            @endphp
                            <th>{{ $shop->name }}</th>
                        @endforeach
    
                    </tr>
                </thead>
                <tbody>
                    @foreach ($criteria_list as $criteria_row)
                        <tr>
                            <th>{{ $criteria_row->name }}</th>
                            <td>{{ round($pv_kriteria_column_total[$criteria_row->id]['pv'], 4)}}</td>
                            @foreach ($shop_list as $shop)
                                @php
                                    $pv = $pv_kriteria_column_total[$criteria_row->id]['shop_list'][$shop->id]['pv'];
                                    $result_list[$shop->id]['pv'] = $result_list[$shop->id]['pv'] * $pv_kriteria_column_total[$criteria_row->id]['pv'] + $pv;
                                @endphp
                                <td>{{ round($pv, 4)}}</td>
                            @endforeach
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="2">Total</th>
                        @foreach($result_list as $result)
                            <td>{{ round($result['pv'], 4) }}</td>
                        @endforeach
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 {{ $class_calculation }}">
            @php
                uasort($result_list, function($a, $b) {
                    if ($a['pv'] == $b['pv']) return 0;
                    return $b['pv'] > $a['pv'];
                })
            @endphp
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Ranking</th>
                        <th>Toko</th>
                        <th>Nilai</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $index = 1;
                    @endphp
                    @foreach($result_list as $shop)
                        <tr>
                            <th>{{ $index }}</th>
                            <td>{{ $shop['data']->name }}</td>
                            <td>{{ round($shop['pv'], 4) }}</td>
                        </tr>
                        @php
                            $index = $index + 1;
                        @endphp
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    </div>
</div>
<div class="row">

    @foreach ($result_list as $shop)
        <x-shop-card :shop="$shop['data']"/>
    @endforeach
</div>
