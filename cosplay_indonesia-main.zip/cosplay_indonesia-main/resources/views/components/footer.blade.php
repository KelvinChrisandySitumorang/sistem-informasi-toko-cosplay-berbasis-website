<footer>
    <div class="container">
    <div class="row">
        <div class="col-md-12">
        <div class="inner-content">
            <p>Copyright &copy; 2021 CosplayIndonesia<a rel="nofollow noopener" href="https://templatemo.com" target="_blank">&nbsp;</a></p>
        </div>
        </div>
    </div>
    </div>
</footer>
