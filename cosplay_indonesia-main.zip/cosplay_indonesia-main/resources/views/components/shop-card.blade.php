<div class="col-md-4">
    <div class="product-item">
        <a href="#"><img src="{{ asset($shop->image) }}" alt=""></a>
        <div class="down-content">
        <a href="#">
            <h4> <strong>{{ $shop->name }} - {{ $shop->phone }}</strong> {{ $shop->city }} - {{ $shop->province }}</h4>
        </a>
        <p>{{ $shop->description }}</p>
        </div>
    </div>
</div>
