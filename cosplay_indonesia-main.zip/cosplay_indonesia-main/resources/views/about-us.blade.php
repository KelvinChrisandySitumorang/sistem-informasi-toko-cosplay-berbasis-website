@extends('layouts.plain')

@section('content')
<!-- Page Content -->
<div class="page-heading about-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
              <h2>mengenal lebih dekat</h2>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="best-features about-features">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Latar Belakang</h2>
            </div>
          </div>
          <div class="col-md-6">
            <div class="right-image">
              <img src="{{ asset('images/foto politeknik negeri jakarta.jpg') }}" alt="">
            </div>
          </div>
          <div class="col-md-6">
            <div class="left-content">
              <p>                kami adalah sekelompok pemuda yang berasal dari Politehnik Negeri Jakarta tahun 2017/2018 Jurusan Tehnik Informatika, kami bercita-cita ingin memajukan umkm cosplay di indonesia dengan cara mempromosikan dan juga memperlihatkan hasil karya yang telah di buat di website kami.<br>
                <br>
                Karena sedikitnya web-web yang membahas tentang cosplay di indonesia,karena itulah tujuan website ini dibuat dan demi memperlihatkan juga hasil karya anak bangsa ke mata dunia.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div class="team-members">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <h2>Tim Kami</h2>
            </div>
          </div>
          <div class="col-md-4">
            <div class="team-member">
              <div class="thumb-container">
                <img src="{{ asset('images/sultan.jpeg') }}" alt="">
                <div class="hover-effect">
                  <div class="hover-content">
                  </div>
                </div>
              </div>
              <div class="down-content">
                <h4>Sultan Rizaldi A</h4>
                <span>4817080493</span>
                <p>Hallo! <br>
                  Saya Sultan Rizaldi Andeny,<br>
                sudah lama saya menekuni hobby cosplay ini dan saya melihat </p>
                <p>potensi besar yang dapat menghasilkan dari hobby ini karena dapat menjual</p>
                <p>kebutuhan cosplay seperti  baju,senjata replika,dan juga aksesoris.</p>
                <p><br>
                Oleh karena itu saya tertarik mengembangkan komunitas ini dengan </p>
                <p>cara mempromosikannya lewat website yang saya dan rekan saya buat ini. </p>
                <p>&nbsp;</p>
                <p>Untuk kedepannya saya harap saya bisa mengembangkan website ini agar</p>
                <p> rekan-rekan Cosplay di Indonesia semakin di kenal dunia, </p>
                <p>sehingga indonesia tidak dipandang sebelah mata.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 offset-xl-4">
            <div class="team-member">
              <div class="thumb-container">
                <img src="{{ asset('images/kelvin.jpeg') }}" alt="">
                <div class="hover-effect">
                  <div class="hover-content">
                  </div>
                </div>
              </div>
              <div class="down-content">
                <h4>Kelvin Chrisandy S</h4>
                <span>4817080342</span>
                <p>Hallo! </p>
                <p>Saya Kelvin Chrisandy,</p>
                <p> Saya sangat suka dalam mengembangkan usaha - usaha menengah kebawah <br>
                dengan mengubah cara berjualan yang konfensional menjadi online. </p>
                <p>Saya membantu umkm cosplay dengan memberikan promosi dalam </p>
                <p>bentuk website yang bertujuan untuk memberikan info kepada  para pencinta cosplay untuk dapat </p>
                <p>menemukan toko cosplay dan juga dapat memberikan rekomendasi toko kepada </p>
                <p>para pencinta cosplay lainnya.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
@endsection
