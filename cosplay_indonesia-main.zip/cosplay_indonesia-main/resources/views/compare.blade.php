@extends('layouts.plain')

@section('content')
<div class="page-heading products-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
            <div class="text-content"></div>
        </div>
      </div>
    </div>
</div>
    <!-- <div class="products">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="filters">
              <ul>
                  <li><a class="nav-link" href="/compare"><font color ="#000000">METODE AHP</font></a></li>
                  <li><a class="nav-link" href="/compare"><font color ="#000000">METODE SMART</font></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-6 col-xl-6">
            <div class="right-image">
              <img src="assets/images/feature-image-01.jpg" alt="">
            </div>
          </div>
          <div class="col-md-6 col-xl-6">
            <div class="left-content">
              <blockquote>
                <blockquote>
                  <p><strong>METODE AHP</strong></p>
                  <p>&quot;Disini terisi list-list toko terbaik menggunakan metode AHP yang telah di data oleh admin website berdasarkan data yang diterima,silahkan memilih toko favorit kalian.&quot;</p>
                  <p><br>
                  </p>
                  <p><strong>METODE SMART</strong></p>
                  <p>&quot;Disini terisi list-list toko terbaik mengguanakan metode SMART yang telah di data oleh admin website berdasarkan perhitungan dan data yang diterima,silahkan memilih toko favorit Kalian&quot;</p>
                  <p class="text-left col-xl-12">&nbsp;</p>
                </blockquote>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </div> -->
    <div class="latest-products">
        <div class="container">
            <x-ahp-data-view/>
        </div>
        <div class="container">
            <x-smart-data-view/>
        </div>
    </div>
@endsection
