<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AhpShopComparisonsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('ahp_shop_comparisons')->insert([
            'shop1_id' => 1,
            'shop2_id' => 2,
            'criteria_id' => 1,
            'value' => 1,
        ]);
        DB::table('ahp_shop_comparisons')->insert([
            'shop1_id' => 1,
            'shop2_id' => 2,
            'criteria_id' => 2,
            'value' => 1,
        ]);
        DB::table('ahp_shop_comparisons')->insert([
            'shop1_id' => 1,
            'shop2_id' => 2,
            'criteria_id' => 3,
            'value' => 1,
        ]);
        DB::table('ahp_shop_comparisons')->insert([
            'shop1_id' => 1,
            'shop2_id' => 3,
            'criteria_id' => 1,
            'value' => 1,
        ]);
        DB::table('ahp_shop_comparisons')->insert([
            'shop1_id' => 2,
            'shop2_id' => 3,
            'criteria_id' => 1,
            'value' => 1,
        ]);
    }
}
