<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        $this->call([
            CriteriaSeeder::class,
            ShopsSeeder::class,
            UsersSeeder::class,
            AhpCriteriaComparisonsSeeder::class,
            AhpShopComparisonsSeeder::class,
            AhpIrSeeder::class,
            SmartCriteriaSeeder::class,
            SmartShopsSeeder::class,
            SmartRelShopsSeeder::class
        ]);
    }
}
