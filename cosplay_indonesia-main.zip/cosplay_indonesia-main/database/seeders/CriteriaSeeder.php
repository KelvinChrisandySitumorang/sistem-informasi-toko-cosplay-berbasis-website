<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CriteriaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('criteria')->insert([
            'name' => 'Harga',
        ]);
        DB::table('criteria')->insert([
            'name' => 'Kualitas',
        ]);
        DB::table('criteria')->insert([
            'name' => 'Waktu',
        ]);
    }
}
