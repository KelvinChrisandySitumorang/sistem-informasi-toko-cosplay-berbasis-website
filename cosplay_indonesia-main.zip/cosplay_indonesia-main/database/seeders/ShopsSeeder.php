<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ShopsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('shops')->insert([
            'name' => 'ryujin.id',
            'phone' => '081383177911',
            'city' => 'Palmerah',
            'province' => 'Jakarta Barat',
            'description' => 'Menyediakan produk Cosplay berbahan Kayu dengan pengerjaan minimal 3 Minggu',
            'image' => 'images/product_01.jpg',
        ]);
        DB::table('shops')->insert([
            'name' => 'gondrong.id',
            'phone' => '083892355737',
            'city' => 'Meruya',
            'province' => 'Jakarta Utara',
            'description' => 'Menyediakan produk Cosplay berbahan Kayu dengan pengerjaan minimal 2 Minggu',
            'image' => 'images/product_02.jpg',
        ]);
        DB::table('shops')->insert([
            'name' => 'black heart',
            'phone' => '089663692580',
            'city' => 'Tanah Baru',
            'province' => 'Jakarta Selatan',
            'description' => 'Menyediakan produk Cosplay berbahan Eva Foam dengan pengerjaan minimal 2 Minggu',
            'image' => 'images/product_03.jpg',
        ]);
        DB::table('shops')->insert([
            'name' => 'Sunshine Shop',
            'phone' => '083892618452',
            'city' => 'Lenteng Agung',
            'province' => 'Jakarta Selatan',
            'description' => 'Menyediakan produk Cosplay berbahan Eva Foam dengan pengerjaan minimal 1 Minggu',
            'image' => 'images/product_04.jpg',
        ]);
        DB::table('shops')->insert([
            'name' => 'Cashin Online',
            'phone' => '081323628452',
            'city' => 'Pondok Gede',
            'province' => 'Jakarta Timur',
            'description' => 'Menyediakan produk Cosplay berbahan Resin Foam dengan pengerjaan minimal 1 Minggu',
            'image' => 'images/product_05.jpg',
        ]);
        DB::table('shops')->insert([
            'name' => 'anime olshop',
            'phone' => '087713254831',
            'city' => 'Kelapa Gading',
            'province' => 'Jakarta Utara',
            'description' => 'Menyediakan produk Cosplay berbahan Resin Foam dengan pengerjaan minimal 2 Minggu',
            'image' => 'images/product_06.jpg',
        ]);
    }
}
