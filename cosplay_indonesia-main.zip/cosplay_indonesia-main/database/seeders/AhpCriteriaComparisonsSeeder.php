<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AhpCriteriaComparisonsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('ahp_criteria_comparisons')->insert([
            'criteria1_id' => 1,
            'criteria2_id' => 2,
            'value' => 1,
        ]);
        DB::table('ahp_criteria_comparisons')->insert([
            'criteria1_id' => 1,
            'criteria2_id' => 3,
            'value' => 1,
        ]);
        DB::table('ahp_criteria_comparisons')->insert([
            'criteria1_id' => 2,
            'criteria2_id' => 3,
            'value' => 1,
        ]);
    }
}
