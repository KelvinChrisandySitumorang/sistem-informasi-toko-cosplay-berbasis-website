<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AhpIrSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('ahp_ir')->insert([
            'total_criteria' => 1,
            'value' => 0,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 2,
            'value' => 0,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 3,
            'value' => 0.58,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 4,
            'value' => 0.9,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 5,
            'value' => 1.12,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 6,
            'value' => 1.24,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 7,
            'value' => 1.32,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 8,
            'value' => 1.41,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 9,
            'value' => 1.45,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 10,
            'value' => 1.49,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 11,
            'value' => 1.51,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 12,
            'value' => 1.48,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 13,
            'value' => 1.156,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 14,
            'value' => 1.57,
        ]);
        DB::table('ahp_ir')->insert([
            'total_criteria' => 15,
            'value' => 1.59,
        ]);
    }
}
