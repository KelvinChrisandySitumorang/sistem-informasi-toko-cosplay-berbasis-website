<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAhpShopComparisonsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ahp_shop_comparisons', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->foreignId('shop1_id')->constrained('shops')->onDelete('cascade');
            $table->foreignId('shop2_id')->constrained('shops')->onDelete('cascade');
            $table->foreignId('criteria_id')->constrained('criteria')->onDelete('cascade');
            $table->float('value');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ahp_shop_comparisons');
    }
}
