<?php

namespace Database\Factories;

use App\Models\SmartRelShop;
use Illuminate\Database\Eloquent\Factories\Factory;

class SmartRelShopFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = SmartRelShop::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
